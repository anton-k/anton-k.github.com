module Main where

main = print $ sum [1 .. 1e5]

