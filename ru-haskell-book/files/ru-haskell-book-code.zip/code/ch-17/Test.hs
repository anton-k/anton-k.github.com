module Test where

class Multi a b where

f = show
