module Main where

import Hello 

main = print helloWorld
