module Utility.Hello where

hello = "Hello"
