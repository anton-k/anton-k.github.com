module Utility.World where

world = "World"
