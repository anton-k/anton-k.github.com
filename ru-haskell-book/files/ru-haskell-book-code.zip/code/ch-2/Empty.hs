module Empty where

import EmptyEmpty
import Sub.Empty
