module Main where

import Loop 

main = gameLoop

